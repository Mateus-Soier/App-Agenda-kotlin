package com.example.agenda

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity6 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main6)
        findViewById<TextView>(R.id.textView4).setOnClickListener {
            salvartipo1()
        }
        findViewById<TextView>(R.id.textView1).setOnClickListener {
            salvartipo2()
        }
        findViewById<TextView>(R.id.textView2).setOnClickListener {
            salvartipo3()
        }
        findViewById<TextView>(R.id.textView7).setOnClickListener {
            salvartipo4()
        }
    }

    fun salvartipo1() {
        val habilidadesalvo : String = intent.getStringExtra("habilidade")!!
        val idiomasalvo : String = intent.getStringExtra("idioma")!!
        val exerciciosalvo : String = intent.getStringExtra("exercico")!!
        val frequenciaalvo : String = intent.getStringExtra("frequencia")!!
        startActivity(
            Intent(this, MainActivity7::class.java)
                .putExtra("habilidade", habilidadesalvo)
                .putExtra("idioma", idiomasalvo)
                .putExtra("exercico", exerciciosalvo)
                .putExtra("frequencia", frequenciaalvo)
                .putExtra("tempo", "15 minutos")
        )
    }

    fun salvartipo2() {
        val habilidadesalvo : String = intent.getStringExtra("habilidade")!!
        val idiomasalvo : String = intent.getStringExtra("idioma")!!
        val exerciciosalvo : String = intent.getStringExtra("exercico")!!
        val frequenciaalvo : String = intent.getStringExtra("frequencia")!!
        startActivity(
            Intent(this, MainActivity7::class.java)
                .putExtra("habilidade", habilidadesalvo)
                .putExtra("idioma", idiomasalvo)
                .putExtra("exercico", exerciciosalvo)
                .putExtra("frequencia", frequenciaalvo)
                .putExtra("tempo", "30 minutos")
        )
    }

    fun salvartipo3() {
        val habilidadesalvo : String = intent.getStringExtra("habilidade")!!
        val idiomasalvo : String = intent.getStringExtra("idioma")!!
        val exerciciosalvo : String = intent.getStringExtra("exercico")!!
        val frequenciaalvo : String = intent.getStringExtra("frequencia")!!
        startActivity(
            Intent(this, MainActivity7::class.java)
                .putExtra("habilidade", habilidadesalvo)
                .putExtra("idioma", idiomasalvo)
                .putExtra("exercico", exerciciosalvo)
                .putExtra("frequencia", frequenciaalvo)
                .putExtra("tempo", "1 hora")
        )
    }

    fun salvartipo4() {
        val habilidadesalvo : String = intent.getStringExtra("habilidade")!!
        val idiomasalvo : String = intent.getStringExtra("idioma")!!
        val exerciciosalvo : String = intent.getStringExtra("exercico")!!
        val frequenciaalvo : String = intent.getStringExtra("frequencia")!!
        startActivity(
            Intent(this, MainActivity7::class.java)
                .putExtra("habilidade", habilidadesalvo)
                .putExtra("idioma", idiomasalvo)
                .putExtra("exercico", exerciciosalvo)
                .putExtra("frequencia", frequenciaalvo)
                .putExtra("tempo", "2 horas")
        )
    }
}