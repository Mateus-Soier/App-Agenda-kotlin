package com.example.agenda

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)
        findViewById<TextView>(R.id.textView4).setOnClickListener {
            salvartipo1()
        }
        findViewById<TextView>(R.id.textView5).setOnClickListener {
            salvartipo2()
        }
        findViewById<TextView>(R.id.textView6).setOnClickListener {
            salvartipo3()
        }
        findViewById<TextView>(R.id.textView7).setOnClickListener {
            salvartipo4()
        }
        findViewById<TextView>(R.id.textView8).setOnClickListener {
            salvartipo5()
        }
        findViewById<TextView>(R.id.textView9).setOnClickListener {
            salvartipo6()
        }
    }

    fun salvartipo1() {
        val habilidadesalvo : String = intent.getStringExtra("habilidade")!!
        startActivity(
            Intent(this, MainActivity5::class.java)
                .putExtra("habilidade", habilidadesalvo)
                .putExtra("idioma", "Árabe")
        )
    }

    fun salvartipo2() {
        val habilidadesalvo : String = intent.getStringExtra("habilidade")!!
        startActivity(
            Intent(this, MainActivity5::class.java)
                .putExtra("habilidade", habilidadesalvo)
                .putExtra("idioma", "Chinês")
        )
    }

    fun salvartipo3() {
        val habilidadesalvo : String = intent.getStringExtra("habilidade")!!
        startActivity(
            Intent(this, MainActivity5::class.java)
                .putExtra("habilidade", habilidadesalvo)
                .putExtra("idioma", "Inglês")
        )
    }

    fun salvartipo4() {
        val habilidadesalvo : String = intent.getStringExtra("habilidade")!!
        startActivity(
            Intent(this, MainActivity5::class.java)
                .putExtra("habilidade", habilidadesalvo)
                .putExtra("idioma", "Híndi")
        )
    }

    fun salvartipo5() {
        val habilidadesalvo : String = intent.getStringExtra("habilidade")!!
        startActivity(
            Intent(this, MainActivity5::class.java)
                .putExtra("habilidade", habilidadesalvo)
                .putExtra("idioma", "Japonês")
        )
    }

    fun salvartipo6() {
        val habilidadesalvo : String = intent.getStringExtra("habilidade")!!
        startActivity(
            Intent(this, MainActivity5::class.java)
                .putExtra("habilidade", habilidadesalvo)
                .putExtra("idioma", "Português")
        )
    }
}