package com.example.agenda

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity8 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main8)
        val exerciciosalvo : String = intent.getStringExtra("exercico")!!
        val frequenciaalvo : String = intent.getStringExtra("frequencia")!!
        val tempoalvo : String = intent.getStringExtra("tempo")!!
        val horarioalvo : String = intent.getStringExtra("horario")!!
        val habilidadesalvo : String = intent.getStringExtra("habilidade")!!
        val idiomasalvo : String = intent.getStringExtra("idioma")!!

        findViewById<TextView>(R.id.textView).text = exerciciosalvo
        findViewById<TextView>(R.id.textView0).text = habilidadesalvo
        findViewById<TextView>(R.id.textView).text = idiomasalvo
        findViewById<TextView>(R.id.textView1).text = frequenciaalvo
        findViewById<TextView>(R.id.textView2).text = tempoalvo
        findViewById<TextView>(R.id.textView3).text = horarioalvo
    }

}