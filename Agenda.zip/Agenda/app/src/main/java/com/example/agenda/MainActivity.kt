package com.example.agenda

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<ImageView>(R.id.imageView3).setOnClickListener {
            selecionarMetaActivity()
        }
        findViewById<ImageView>(R.id.imageView7).setOnClickListener {
            selecionarMetaActivity2()
        }
    }

    private fun selecionarMetaActivity(){
        startActivity(Intent(this, MainActivity2::class.java))
    }

    private fun selecionarMetaActivity2(){
        startActivity(Intent(this, MainActivity3::class.java))
    }
}

