package com.example.agenda

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        findViewById<TextView>(R.id.textView4).setOnClickListener {
            salvartipo1()
        }
        findViewById<TextView>(R.id.textView1).setOnClickListener {
            salvartipo2()
        }
        findViewById<TextView>(R.id.textView2).setOnClickListener {
            salvartipo3()
        }
        findViewById<TextView>(R.id.textView7).setOnClickListener {
            salvartipo4()
        }
        findViewById<TextView>(R.id.textView8).setOnClickListener {
            salvartipo5()
        }
    }
    fun salvartipo1() {
        startActivity(
            Intent(this, MainActivity5::class.java)
                .putExtra("exercico", "malhar")
        )
    }

    fun salvartipo2() {
        startActivity(
            Intent(this, MainActivity5::class.java)
                .putExtra("exercico", "correr")
        )
    }

    fun salvartipo3() {
        startActivity(
            Intent(this, MainActivity5::class.java)
                .putExtra("exercico", "caminhar")
        )
    }

    fun salvartipo4() {
        startActivity(
            Intent(this, MainActivity5::class.java)
                .putExtra("exercico", "Fazer yoga")
        )
    }

    fun salvartipo5() {
        startActivity(
            Intent(this, MainActivity5::class.java)
                .putExtra("exercico", "Personalizar")
        )
    }

}