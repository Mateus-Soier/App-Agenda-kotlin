package com.example.agenda

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        findViewById<TextView>(R.id.textView4).setOnClickListener {
            salvartipo1()
        }
        findViewById<TextView>(R.id.textView5).setOnClickListener {
            salvartipo2()
        }
        findViewById<TextView>(R.id.textView6).setOnClickListener {
            salvartipo3()
        }
        findViewById<TextView>(R.id.textView7).setOnClickListener {
            salvartipo4()
        }
    }

    fun salvartipo1() {
        startActivity(
            Intent(this, MainActivity4::class.java)
                .putExtra("habilidade", "Aprender um idioma")
        )
    }

    fun salvartipo2() {
        startActivity(
            Intent(this, MainActivity4::class.java)
                .putExtra("habilidade", "Aprender programação")
        )
    }

    fun salvartipo3() {
        startActivity(
            Intent(this, MainActivity4::class.java)
                .putExtra("habilidade", "Praticar um instrumento")
        )
    }

    fun salvartipo4() {
        startActivity(
            Intent(this, MainActivity4::class.java)
                .putExtra("habilidade", "Fazer arte")
        )
    }
}